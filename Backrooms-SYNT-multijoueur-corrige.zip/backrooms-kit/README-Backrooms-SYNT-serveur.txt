# Backrooms SYNT — salons publics en ligne

Ce dossier contient :
- `backrooms-synt-public-rooms.html` : le jeu modifié avec une liste de salons publics.
- `server.js` : le serveur WebSocket qui maintient la liste et relaie les positions/messages.
- `package.json` : dépendances et commande de démarrage.
- `render.yaml` : configuration de déploiement Render.

## Important : ce serveur n'est PAS hébergé automatiquement

Le code est prêt à être lancé ou déployé, mais il faut démarrer le serveur sur un ordinateur accessible ou le déployer sur un hébergeur. Aucun serveur en ligne n'a été créé par ce paquet.

## Test local

1. Installe Node.js 18 ou plus récent.
2. Ouvre un terminal dans ce dossier.
3. Lance `npm install`, puis `npm start`.
4. Ouvre `backrooms-synt-public-rooms.html` dans ton navigateur.
5. Dans le menu MULTIJOUEUR, laisse `ws://localhost:8080`, clique sur **Se connecter et actualiser la liste**, puis crée un salon.
6. Ouvre le même fichier dans un autre navigateur/onglet sur le même ordinateur pour tester la liste. Pour un autre ordinateur, `localhost` désigne cet autre ordinateur : il faudra utiliser l'adresse IP du PC serveur et autoriser le port 8080 sur le réseau local.

La page `http://localhost:8080/health` doit répondre avec un JSON contenant `ok: true`.

## Déploiement en ligne sur Render

1. Décompresse le ZIP et place le contenu dans un dépôt GitHub.
2. Sur Render, crée un nouveau **Web Service** à partir de ce dépôt.
3. Render détectera `render.yaml`; sinon configure :
   - Build command : `npm install`
   - Start command : `npm start`
4. Après déploiement, copie l'adresse HTTPS de Render et transforme `https://nom-service.onrender.com` en `wss://nom-service.onrender.com`.
5. Ouvre le fichier HTML du jeu, colle cette adresse dans **Adresse du serveur multijoueur**, puis clique **Se connecter et actualiser la liste**.

Pour que des amis rejoignent, ils doivent eux aussi utiliser la même adresse WSS du serveur dans leur fichier du jeu. Le serveur gratuit peut se mettre en veille; le premier raccordement peut donc prendre un moment.

## Limites de cette version

- La liste publique, création/rejoindre, chat et positions des joueurs passent par le serveur.
- Les joueurs voient les avatars les uns des autres dans le même niveau.
- Les monstres, objets ramassés, portes, objectifs, inventaires et progression ne sont pas encore synchronisés comme un vrai monde autoritaire partagé.
- Aucun test de jeu à deux appareils distants n'a été possible ici. Le code peut être contrôlé syntaxiquement, mais le déploiement et le test réseau réel doivent être faits après hébergement.
